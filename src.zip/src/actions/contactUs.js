import {GET_CONTACT_DETAIL} from '../constants/actionTypes';

export const getContactData = payload => ({
   
    type:GET_CONTACT_DETAIL,
    payload:payload,
    
});

